package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandsOn6MockMVC_TestGetCountryService  {

	public static void main(String[] args) {
		SpringApplication.run(HandsOn6MockMVC_TestGetCountryService.class, args);
	}

}
