package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandsOn3RestGetAllCountries {

	public static void main(String[] args) {
		SpringApplication.run(HandsOn3RestGetAllCountries.class, args);
	}

}
